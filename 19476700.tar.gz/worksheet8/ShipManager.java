/*****************************************************************************
AUTHOR: Tawana David Kwaramba
FILENAME: UI.java
STUDENT ID: 19476700
LAST MODifIED:
PURPOSE: A class which is reponsible for all the user input and output.
******************************************************************************/
public class ShipManager 
{
    public static void main(String [] args)
    {
        UI userInterface = new UI();
        userInterface.mainMenu();
    }
}
/*
    create a new UI object with the name userInterface
    userInterface.mainMenu
    
END MAIN:*/
